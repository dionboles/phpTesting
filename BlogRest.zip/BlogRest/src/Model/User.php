<?php 
namespace App\Model;

use App\Models\User;

class User {
    protected $database;
    public function __construct(\PDO $database){
        $this -> $database = $database;
    }
    pu
}