<?php
 $sql  = "INSERT INTO Payments SET school_id = ";
 $stmt= $conn->prepare($sql);

 ?>